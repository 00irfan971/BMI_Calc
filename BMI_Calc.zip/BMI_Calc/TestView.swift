//
//  TestView.swift
//  Learn_Textfields
//
//  Created by Irfan on 13/07/24.
//

import SwiftUI

struct TestView: View {
    @State var num:String=""
    var body: some View {
        Text(/*@START_MENU_TOKEN@*/"Hello, World!"/*@END_MENU_TOKEN@*/)
        
        TextField("apple", text:$num)
        
        
        
        
    }
}

#Preview {
    TestView()
}
