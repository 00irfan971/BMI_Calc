//
//  Learn_TextfieldsApp.swift
//  Learn_Textfields
//
//  Created by Irfan on 13/06/24.
//

import SwiftUI
import SwiftData

class SharedData: ObservableObject {
    @Published var Gender: String = ""
    @Published var age:String=""
    
    @Published var height:String=""
    @Published var weight:String=""
    
    func reseting() {
        DispatchQueue.main.async {
            
            print(self.Gender)
            self.Gender=""
            print(self.Gender)
            print(self.age)
            self.age=""
            print(self.age)
            print(self.height)
            self.height=""
            print(self.height)
            print(self.weight)
            self.weight=""
            print(self.weight)
        }
        
    }
   
}

@main
struct Learn_TextfieldsApp: App {
    
    @StateObject var sharedData=SharedData()
    
    var body: some Scene {
        WindowGroup {
            ContentView().environmentObject(sharedData)
        }
    }
}
