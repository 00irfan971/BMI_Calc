//
//  BMIView.swift
//  Learn_Textfields
//
//  Created by Irfan on 17/06/24.
//

import SwiftUI

struct BMIView: View {
    @EnvironmentObject var sharedData: SharedData
    
    
    
        
    
    var body: some View {
        
        NavigationView{
            ZStack{
                Color.black.ignoresSafeArea().opacity(0.9)
                
                VStack{
                    Text("Enter your Gender").foregroundStyle(.white).font(.largeTitle)
                    
                    HStack{
                        
                        Button(action: { sharedData.Gender="Male"}, label: {
                            
                            sharedData.Gender == "Male" ? GenderButton(icon: "mustache", text: "Male",col: .cyan) : GenderButton(icon: "mustache", text: "Male",col: .white)
                        })
                        
                        
                        Button(action: {sharedData.Gender="Female"}, label: {
                            sharedData.Gender == "Female" ? GenderButton(icon: "mouth", text: "Female",col: .pink) : GenderButton(icon: "mouth", text: "Female",col: .white)
                        })
                    
                    }.padding()
                    
                    if sharedData.Gender==""{
                        ProceedButton(col: Color.red,st:true)
                    }
                    else{
                        ProceedButton(col: Color.green,st:false)
                    }

                }
                
            }

            
        }
        
            }
}

#Preview {
    BMIView().environmentObject(SharedData())
}

struct GenderButton: View {
    
    var icon:String
    var text:String
    var col:Color
    var body: some View {
        Label(text,systemImage: icon).foregroundStyle(col).frame(width:180,height:100).background(.black).border(col).cornerRadius(9)
    }
}

struct ProceedButton: View {
    
    var col:Color
    var st:Bool
    var body: some View {
        NavigationLink(destination: AgeView().navigationBarBackButtonHidden(true), label: {
            Text(" Proceed     ").font(.title2).foregroundColor(Color.white).frame(width:300,height:38).background(col.opacity(0.6)).cornerRadius(50)
            
        }).disabled(st)
    }
}

