//
//  CalcView.swift
//  Learn_Textfields
//
//  Created by Irfan on 25/06/24.
//

import SwiftUI

struct CalcView: View {
    var BMI:Float=20.0
    var Gender:String="Male"
    var hstatus:String="Healthy"
    
    func calcBMI() ->Float{
        var calcBMI:Float
        var heighty=(heightx!/100)
        
        calcBMI=(weightx! )/(heighty*heighty)
        
        return calcBMI
    }

    @EnvironmentObject var sharedData: SharedData
    
    var agex:Int?{
        Int(sharedData.age)
    }
    
    var heightx:Float?{
        Float(sharedData.height)
    }
    var weightx:Float?{
        Float(sharedData.weight)
    }
    
    var body: some View {
        if agex!>=20{
            if calcBMI()>18.5 && calcBMI()<25.0{
                FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                
                
                }
            else if calcBMI()<18.5{
                FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                
            }
            else if calcBMI()>24.9 && calcBMI()<29.9{
                FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
            }
            else if calcBMI()>=30{
                FinalView(hstatus: "Your are Obese !", BMI: calcBMI(),col:"RED")
            }
            
            }
        
        else{
            
            if sharedData.Gender=="Male"{
                if agex!==19{
                    if calcBMI()>=18.6 && calcBMI()<=26.1{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<18.6{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>26.1{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==18{
                    if calcBMI()>=18.2 && calcBMI()<=25.6{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<18.2{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>25.6{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==17{
                    if calcBMI()>=17.7 && calcBMI()<=25{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<17.7{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>25{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==16{
                    if calcBMI()>=16.6 && calcBMI()<=24.4{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<16.6{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>24.4{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==15{
                    if calcBMI()>=16.5 && calcBMI()<=23.5{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<16.5{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>23.5{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==14{
                    if calcBMI()>=16 && calcBMI()<=22.6{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<16{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>22.6{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==13{
                    if calcBMI()>=15.5 && calcBMI()<=21.8{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<15.7{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>21.8{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==12{
                    if calcBMI()>=15.5 && calcBMI()<=21{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<15.5{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>21{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                else if agex!==11{
                    if calcBMI()>=14.5 && calcBMI()<=20.3{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<14.5{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>20.3{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
            }
            
            else if sharedData.Gender=="Female"{
                if agex!==19{
                    if calcBMI()>=18.4 && calcBMI()<=26.1{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<18.4{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>26.1{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==18{
                    if calcBMI()>=18.2 && calcBMI()<=25.6{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<18.2{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>25.6{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==17{
                    if calcBMI()>=17.7 && calcBMI()<=25.2{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<17.7{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>25.2{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==16{
                    if calcBMI()>=17.4 && calcBMI()<=24.7{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<17.4{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>24.7{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==15{
                    if calcBMI()>=16.9 && calcBMI()<=24{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<16.9{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>24{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==14{
                    if calcBMI()>=15.4 && calcBMI()<=23.3{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<15.4{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>23.3{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==13{
                    if calcBMI()>=15.9 && calcBMI()<=22.5{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<15.9{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>22.5{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                
                else if agex!==12{
                    if calcBMI()>=15.4 && calcBMI()<=21.8{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<15.4{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>21.8{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }
                else if agex!==11{
                    if calcBMI()>=14.1 && calcBMI()<=20.8{
                        FinalView(hstatus: "Congratulations! Your are healthy !", BMI: calcBMI(),col:"GREEN")
                        
                    }
                    else if calcBMI()<14.1{
                        FinalView(hstatus: "Your are Underweight !", BMI: calcBMI(),col:"RED")
                        
                    }
                    else if calcBMI()>20.8{
                        FinalView(hstatus: "You are Over Weight", BMI: calcBMI(), col: "RED")
                    }
                }//
                else {
                    
                    FinalView(hstatus: "Age Invalid", BMI: 0.0, col: "RED")
                    
                }

                
            }
            }
    
    }
}

#Preview {
    CalcView()
}



struct FinalView: View {
    
    var hstatus:String
    var BMI:Float
    var col:String
    var body: some View {
        ZStack{
            Color(col).ignoresSafeArea()
            
            VStack{
                
                Text("Your BMI :").font(.system(size: 30,design: .rounded)).fontWeight(.bold).padding()
                
                
                
                Text("\(BMI,specifier: "%.1f")").font(.system(size: 90,design:.rounded)).fontWeight(.bold).foregroundStyle(Color.white)
                
                Text("\(hstatus)").font(.title2).fontWeight(.semibold).frame(height: 1)
                
                
                
                
            }
            
            
            
        }
    }
}
