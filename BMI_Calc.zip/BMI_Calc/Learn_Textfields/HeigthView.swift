//
//  HeigthView.swift
//  Learn_Textfields
//
//  Created by Irfan on 19/06/24.
//

import SwiftUI

struct HeigthView: View {
    
    @EnvironmentObject var sharedData: SharedData
    var body: some View {
        NavigationView{
            
            ZStack{
                Color.black.ignoresSafeArea().opacity(0.9)
                
                VStack{
                    Text("Enter your Height ( cm )").foregroundStyle(.white).font(.largeTitle)
                    
                    TextField("Centimeters", text: $sharedData.height).foregroundColor(.black).keyboardType(.numberPad).frame(height: 40).background(Color.white.opacity(0.8)).cornerRadius(5.0).padding()
                    
                                        
                    if sharedData.height==""{
                        ProceedButton2(col: Color.red,st:true)
                        
                        NavigationLink(destination: BMIView().onAppear(perform: {
                            sharedData.reseting()
                        }).navigationBarBackButtonHidden(true), label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                    else{
                        ProceedButton2(col: Color.green,st:false)
                        
                        NavigationLink(destination: BMIView().onAppear(perform: {
                            sharedData.reseting()
                        }).navigationBarBackButtonHidden(true), label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                                    
                    
                }
            }
            
            
            
        }
    }
}

#Preview {
    HeigthView().environmentObject(SharedData())
}

struct ProceedButton2: View {
    
    var col:Color
    var st:Bool
    var body: some View {
        NavigationLink(destination: WeightView().navigationBarBackButtonHidden(true), label: {
            Text(" Proceed     ").font(.title2).foregroundColor(Color.white).frame(width:300,height:38).background(col.opacity(0.6)).cornerRadius(50)
            
        }).disabled(st)
    }
}
