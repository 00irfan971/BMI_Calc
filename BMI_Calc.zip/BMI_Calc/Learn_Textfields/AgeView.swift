//
//  AgeView.swift
//  Learn_Textfields
//
//  Created by Irfan on 18/06/24.
//

import SwiftUI

struct AgeView: View {
    @EnvironmentObject var sharedData: SharedData
    
    var agex:Int?{
        Int(sharedData.age)
    }
    
    var body: some View {
        NavigationView{
            
            ZStack{
                Color.black.ignoresSafeArea().opacity(0.9)
                
                VStack{
                    Text("Enter your Age").foregroundStyle(.white).font(.largeTitle)
                    
                    
                    TextField("0", text: $sharedData.age).foregroundColor(.black).keyboardType(.numberPad).frame(height: 40).background(Color.white.opacity(0.8)).cornerRadius(5.0).padding()
                    
                   
                    
                                        
                    if sharedData.age==""{
                        ProceedButton1(col: Color.red,st:true)
                        
                        NavigationLink(destination: BMIView().onAppear(perform: {
                            sharedData.reseting()
                        }).navigationBarBackButtonHidden(true)
                                       , label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                    else{
                        ProceedButton1(col: Color.green,st:false)
                        
                        
                        NavigationLink(destination: BMIView().onAppear(perform: {
                            sharedData.reseting()
                        }).navigationBarBackButtonHidden(true), label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                                    
                    
                }
            }
            
            
            
        }
        
        
    }
                
}

#Preview {
    AgeView().environmentObject(SharedData())
}

struct ProceedButton1: View {
    
    var col:Color
    var st:Bool
    var body: some View {
        NavigationLink(destination: HeigthView().navigationBarBackButtonHidden(true), label: {
            Text(" Proceed     ").font(.title2).foregroundColor(Color.white).frame(width:300,height:38).background(col.opacity(0.6)).cornerRadius(50)
            
        }).disabled(st)
    }
}

