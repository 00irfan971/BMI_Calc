//
//  WeightView.swift
//  Learn_Textfields
//
//  Created by Irfan on 20/06/24.
//

import SwiftUI
import Combine


struct WeightView: View {
    @EnvironmentObject var sharedData: SharedData
    
    @State var sheet:Bool=false
    
    
    var body: some View {
        NavigationView{
            
            ZStack{
                Color.black.ignoresSafeArea().opacity(0.9)
                
                VStack{
                    Text("Enter your weight ( kg )").foregroundStyle(.white).font(.largeTitle)
                    
                    TextField("Weight in kg", text: $sharedData.weight).foregroundColor(.black).keyboardType(.numberPad).frame(height: 40).background(Color.white.opacity(0.8)).cornerRadius(5.0).padding()
                    
                                        
                    if sharedData.weight==""{
                        Button(action: {
                            sheet.toggle()}, label: {
                                Text(" Calculate      ").font(.title2).foregroundColor(Color.white).frame(width:300,height:38).background(Color.red.opacity(0.6)).cornerRadius(50)
                            
                            }).disabled(sharedData.weight=="")
                        
                        NavigationLink(destination: BMIView().onAppear{
                            sharedData.reseting()
                        }.navigationBarBackButtonHidden(true), label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                    else{
                        Button(action: {
                            sheet.toggle()}, label: {
                                Text(" Calculate  ").font(.title2).foregroundColor(Color.white).frame(width:300,height:38).background(Color.green.opacity(0.6)).cornerRadius(50)
                            
                            })
                        
                        NavigationLink(destination: BMIView().onAppear{
                            sharedData.reseting()}.navigationBarBackButtonHidden(true), label: {
                            Text(" Reset   ").font(.title2).foregroundColor(Color.white).frame(width:100,height:38).background(Color.gray.opacity(0.6)).cornerRadius(50)
                            
                        }).padding()
                    }
                    
                }
            }.sheet(isPresented: $sheet, content: {
                CalcView()
            })
            
            
            
        }
    }
}

#Preview {
    WeightView().environmentObject(SharedData())
}




