//
//  ContentView.swift
//  Learn_Textfields
//
//  Created by Irfan on 13/06/24.
//

import SwiftUI
import SwiftData

struct ContentView: View {
    
    var body: some View {
        
        
        
        BMIView().environmentObject(SharedData())
    }
}

#Preview {
    
    ContentView()
        
}
